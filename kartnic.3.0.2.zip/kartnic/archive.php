<?php
/**
 * Archive Page Template
 *
 * @package Kartnic
 */
?>
<header <?php kartnic_do_attr( 'page-header' ); ?>>
    <?php do_action( 'kartnic_before_archive_title' ); ?>

    <h1 class="page-title">
        <?php the_archive_title(); ?>
    </h1>

    <?php do_action( 'kartnic_after_archive_title' ); ?>
</header>

<div class="archive-content">
    <?php if ( have_posts() ) : ?>
        <?php while ( have_posts() ) : the_post(); ?>
            <article <?php post_class(); ?>>
                <h2 class="entry-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                <div class="entry-content">
                    <?php the_excerpt(); ?>
                </div>
            </article>
        <?php endwhile; ?>
    <?php else : ?>
        <p><?php esc_html_e( 'No posts found.', 'kartnic' ); ?></p>
    <?php endif; ?>
</div>
