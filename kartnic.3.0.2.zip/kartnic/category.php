<?php get_header(); ?>
<div class="site-content-area" id="content">
    <h1 class="page-title">
        <?php the_archive_title(); ?>
    </h1>
  
    <div class="site-cont" id="cont-site">
        <?php if ( have_posts() ) : ?>
            <?php while ( have_posts() ) : the_post(); ?>
                <article>
                    <div class="inside-article">
                        <?php if ( has_post_thumbnail() ) : ?>
                        <div class="post-image">
                            <a href="<?php the_permalink(); ?>">
                                <img src="<?php echo wp_get_attachment_image_src(get_post_thumbnail_id(),'large')[0]; ?>" />
                            </a>
                        </div>
                        <?php endif; ?>

                        <header class="entry-header">
                            <h2 class="main-entry-title" itemprop="headline">
                                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                            </h2>
                            <div class="entry-meta">
                                <span class="posted-on"><?php echo get_the_date(); ?></span> 
                                <span class="byline">  by 
                                    <span class="author vcard" itemprop="author" itemtype="https://schema.org/Person" itemscope="">
                                        <a class="url fn n" href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>" title="View all posts by <?php the_author(); ?>" rel="author" itemprop="url">
                                            <span class="author-name" itemprop="name"><?php the_author(); ?></span>
                                         </a>
                                    </span>
                                </span>
                            </div>
                        </header>
                    </div>

                    <div class="entry-summary" itemprop="text"><?php the_excerpt(); ?></div>
                    <a href="<?php the_permalink(); ?>"><input type="button" value="Read more" name=" "></a>
                </article>
            <?php endwhile; ?>
        <?php else : ?>
            <p><?php _e( 'No posts found.', 'kartnic' ); ?></p>
        <?php endif; ?>
    </div>
    <div class="pagination">
        <?php
        the_posts_pagination( array(
            'mid_size'  => 0,
            'end_size'  => 1,
            'prev_text' => __( '← Previous', 'kartnic' ),
            'next_text' => __( 'Next →', 'kartnic' ),
        ) );
        ?>
    </div>
</div>
<?php get_footer(); ?>
