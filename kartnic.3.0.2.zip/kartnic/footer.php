<section class="custom-footer-section">
    <?php
    // Check if at least one footer widget is active
    if (is_active_sidebar('footer1') || is_active_sidebar('footer2') || is_active_sidebar('footer3') || is_active_sidebar('footer4')) :
    ?>
        <footer class="custom-footer">
            <div class="footer-1">
                <div class="inside-footer-widgets">
                    <div class="footer-widget-1">
                        <?php if (is_active_sidebar('footer1')): ?>
                            <?php dynamic_sidebar('footer1'); ?>
                        <?php endif; ?>
                    </div>
                    <div class="footer-widget-2">
                        <?php if (is_active_sidebar('footer2')): ?>
                            <?php dynamic_sidebar('footer2'); ?>
                        <?php endif; ?>
                    </div>
                    <div class="footer-widget-3">
                        <?php if (is_active_sidebar('footer3')): ?>
                            <?php dynamic_sidebar('footer3'); ?>
                        <?php endif; ?>
                    </div>
                    <div class="footer-widget-4">
                        <?php if (is_active_sidebar('footer4')): ?>
                            <?php dynamic_sidebar('footer4'); ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </footer>
    <?php endif; ?>
</section>

<footer class="site-info">
    <div class="inside-site-info">
        <div class="copyright-bar">
            <?php echo kartnic_dynamic_copyright(); ?>
        </div>
    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
