<?php
function kartnic_theme_setup() {
    add_theme_support('automatic-feed-links');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-header', array(
        'header-text' => true,
        // other settings
    ));
     
    add_theme_support('custom-background');
    add_theme_support('title-tag'); // Added title-tag support
    add_editor_style(); // Added editor style support

    // Add support for block styles.
    add_theme_support('wp-block-styles');

    // Add support for responsive embedded content.
    add_theme_support('responsive-embeds');

    // Add support for HTML5 markup.
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ));

    function kartnic_custom_logo_setup() {
        $defaults = array(
            'height'      => 100,
            'width'       => 400,
            'flex-height' => true,
            'flex-width'  => true,
            'header-text' => array('site-title', 'site-description'),
            'unlink-homepage-logo' => true,
        );
        add_theme_support('custom-logo', $defaults);
    }
    add_action('after_setup_theme', 'kartnic_custom_logo_setup');

    // Add support for wide alignment.
    add_theme_support('align-wide');
}
add_action('after_setup_theme', 'kartnic_theme_setup');

add_filter('auto_update_theme', '__return_true');

add_action('wp', function() {
    remove_action('kartnic_after_loop', 'kartnic_do_post_navigation');
});

add_post_type_support('page', 'excerpt');

function kartnic_search_button() {
    ?>
    <span class="search-button" tabindex="0">
        <a role="button" aria-label="<?php echo esc_attr_e('Open search', 'kartnic'); ?>" data-gpmodal-trigger="search">
            <span class="icon-search">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search">
                    <circle cx="11" cy="11" r="8"/>
                    <line x1="21" y1="21" x2="16.65" y2="16.65"/>
                </svg>
            </span>    
        </a>
    </span>
    <?php
}

function kartnic_enqueue_styles() {
    wp_enqueue_style('kartnic-style', get_template_directory_uri() . '/style.css', array(), wp_get_theme()->get('Version'));
}
add_action('wp_enqueue_scripts', 'kartnic_enqueue_styles');



function custom_typography_css() {
    ?>
    <style type="text/css">

.single-post h1 {
    font-size: <?php echo esc_attr('H1_font_size', '16px'); ?>;
    font-weight: <?php echo esc_attr('H1_font_weight', '400'); ?>;
    letter-spacing: <?php echo esc_attr('H1_letter_spacing', '0px'); ?>;
    line-height: <?php echo esc_attr('H1_line_height', '1.5'); ?>;
}
.single-post h2 {
    font-size: <?php echo esc_attr('H2_font_size', '16px'); ?>;
    font-weight: <?php echo esc_attr('H2_font_weight', '400'); ?>;
    letter-spacing: <?php echo esc_attr('H2_letter_spacing', '0px'); ?>;
    line-height: <?php echo esc_attr('H2_line_height', '1.5'); ?>;
}
.single-post h3 {
    font-size: <?php echo esc_attr('H3_font_size', '16px'); ?>;
    font-weight: <?php echo esc_attr('H3_font_weight', '400'); ?>;
    letter-spacing: <?php echo esc_attr('H3_letter_spacing', '0px'); ?>;
    line-height: <?php echo esc_attr('H3_line_height', '1.5'); ?>;
}
.single-post h4 {
    font-size: <?php echo esc_attr('H4_font_size', '16px'); ?>;
    font-weight: <?php echo esc_attr('H4_font_weight', '400'); ?>;
    letter-spacing: <?php echo esc_attr('H4_letter_spacing', '0px'); ?>;
    line-height: <?php echo esc_attr('H4_line_height', '1.5'); ?>;
}
.single-post h5 {
    font-size: <?php echo esc_attr('H5_font_size', '16px'); ?>;
    font-weight: <?php echo esc_attr('H5_font_weight', '400'); ?>;
    letter-spacing: <?php echo esc_attr('H5_letter_spacing', '0px'); ?>;
    line-height: <?php echo esc_attr('H5_line_height', '1.5'); ?>;
}
.single-post h6 {
    font-size: <?php echo esc_attr('H6_font_size', '16px'); ?>;
    font-weight: <?php echo esc_attr('H6_font_weight', '400'); ?>;
    letter-spacing: <?php echo esc_attr('H6_letter_spacing', '0px'); ?>;
    line-height: <?php echo esc_attr('H6_line_height', '1.5'); ?>;
}
.single-post p {
    font-size: <?php echo esc_attr('paragraph_font_size', '16px'); ?>;
    font-weight: <?php echo esc_attr('paragraph_font_weight', '400'); ?>;
    letter-spacing: <?php echo esc_attr('paragraph_letter_spacing', '0px'); ?>;
    line-height: <?php echo esc_attr('paragraph_line_height', '1.5'); ?>;
    margin-bottom: <?php echo esc_attr('paragraph_bottom_margin', '0px'); ?>;
    font-family: <?php echo esc_attr('paragraph_font_family', 'Arial, sans-serif'); ?>;
}

#site-navigation {
            background-color: <?php echo esc_attr('nav_bg_color', '#333333'); ?>;
        }
        #site-navigation a {
            color: <?php echo esc_attr('nav_text_color', '#ffffff'); ?>;
        }
        .mobile-drop-navigation {
            background-color: <?php echo esc_attr('nav_bg_color', '#333333'); ?>;
        }
        .mobile-drop-navigation a {
            color: <?php echo esc_attr('nav_text_color', '#ffffff'); ?>;
        }
        button, .submit {
            background-color: <?php echo esc_attr('button_bg_color', '#333333'); ?>;
            color: <?php echo esc_attr('button_text_color', '#ffffff'); ?>;
        }       .site-info {
            background-color: <?php echo esc_attr('footer_bg_color', '#333333'); ?>;
            color: <?php echo esc_attr('footer_text_color', '#ffffff'); ?>;
        }
        .middle-right-bottom .widget  {
            background-color: <?php echo esc_attr('sidebar_bg_color', '#333333'); ?>;
            color: <?php echo esc_attr('sidebar_text_color', '#ffffff'); ?>;
        }
        .post-navigation {
            background-color: <?php echo esc_attr('post_navigation_bg_color', '#f0f0f0'); ?>;
            .nav-previous a, .nav-next a {
                color: <?php echo esc_attr('post_navigation_text_color', '#333333'); ?>;
            }
        }
        .post-site-main article {
            background-color: <?php echo esc_attr('post_site_main_bg_color', '#ffffff'); ?> !important;
            color: <?php echo esc_attr('post_site_main_text_color', '#000000'); ?> !important;
        }
        .site-cont article, .comments-area {
    background-color: <?php echo esc_attr('site_cont_bg_color', '#ffffff'); ?> !important;
    color: <?php echo esc_attr('site_cont_text_color', '#000000'); ?> !important;
}

.nav-links {
    background-color: <?php echo esc_attr('pagination_bg_color', '#f0f0f0'); ?> !important;
    color: <?php echo esc_attr('pagination_text_color', '#333333'); ?> !important;
}


    </style>
    <?php
}
add_action('wp_head', 'custom_typography_css');
 

function kartnic_customize_css() {
    ?>
    <style type="text/css">
        .focus-element {
            color: <?php echo esc_attr(get_theme_mod('focus_color', '#0d00ff')); ?> !important;
        }
        a:active {
            color: <?php echo esc_attr(get_theme_mod('focus_color', '#0d00ff')); ?> !important;
        }
        .site-header {
            background-color: <?php echo esc_attr(get_theme_mod('header_bg_color', '#ffffff')); ?> !important;
            color: <?php echo esc_attr(get_theme_mod('header_text_color', '#000000')); ?> !important;
        }
        .site-header a {
            color: <?php echo esc_attr(get_theme_mod('header_text_color', '#000000')); ?> !important;
        }
    </style>
    <?php
}
add_action('wp_head', 'kartnic_customize_css');

function kartnic_display_author_card($author_id) {
    $author = get_userdata($author_id);
    if ($author) {
        ?>
        <div class="kartnic-author-card">
            <div class="kartnic-author-avatar">
                <?php echo get_avatar($author->ID, 96); ?>
            </div>
            <h2><?php echo esc_html($author->display_name); ?></h2>
            <?php if ( get_the_author_meta('description', $author->ID) ) : ?>
                <div class="kartnic-author-description">
                    <p><?php echo esc_html(get_the_author_meta('description', $author->ID)); ?></p>
                </div>
            <?php endif; ?>
        </div>
        <?php
    }
}

function kartnic_register_menus() {
    register_nav_menus(
        array(
            'primary-menu' => __( 'Menu', 'kartnic' ),
        )
    );
}
add_action( 'init', 'kartnic_register_menus' );

function kartnic_customizer_settings($wp_customize) {
    // Add panel for General Settings
    $wp_customize->add_panel('kartnic_general_settings_panel', array(
        'title' => __('General Settings', 'kartnic'),
        'priority' => 30,
    ));

    // Add sub-section for Navigation Settings within General Settings panel
    $wp_customize->add_section('kartnic_navigation_section', array(
        'title' => __('Navigation Settings', 'kartnic'),
        'priority' => 30,
        'panel' => 'kartnic_general_settings_panel',
    ));

    // Add setting for post navigation
    $wp_customize->add_setting('kartnic_enable_post_navigation', array(
        'default' => true,
        'sanitize_callback' => 'wp_validate_boolean',
    ));

    // Add control for post navigation
    $wp_customize->add_control('kartnic_enable_post_navigation', array(
        'type' => 'checkbox',
        'section' => 'kartnic_navigation_section', // Use the Navigation Settings section
        'label' => __('Enable Post Navigation', 'kartnic'),
        'description' => __('Show or hide the next/previous post links.', 'kartnic'),
    ));

    // Add sub-section for Author Card Visibility within General Settings panel
    $wp_customize->add_section('kartnic_author_card_section', array(
        'title' => __('Author Card Settings', 'kartnic'),
        'priority' => 35, // Position it below Navigation Settings
        'panel' => 'kartnic_general_settings_panel',
    ));

    // Add setting for author card visibility
    $wp_customize->add_setting('kartnic_author_card_visibility', array(
        'default' => true,
        'sanitize_callback' => 'wp_validate_boolean',
    ));

    // Add control for author card visibility
    $wp_customize->add_control('kartnic_author_card_visibility_control', array(
        'label' => __('Show Author Card', 'kartnic'),
        'section' => 'kartnic_author_card_section', // Use the Author Card Settings section
        'settings' => 'kartnic_author_card_visibility',
        'type' => 'checkbox',
    ));

    // Add sub-section for Back to Top Button within General Settings panel
    $wp_customize->add_section('kartnic_back_to_top_section', array(
        'title' => __('Back to Top Button', 'kartnic'),
        'priority' => 40,
        'panel' => 'kartnic_general_settings_panel',
    ));

    // Add setting for back to top button
    $wp_customize->add_setting('kartnic_back_to_top', array(
        'default' => false,
        'sanitize_callback' => 'wp_validate_boolean',
    ));

    // Add control for back to top button
    $wp_customize->add_control('kartnic_back_to_top_control', array(
        'label' => __('Enable Back to Top Button', 'kartnic'),
        'section' => 'kartnic_back_to_top_section', // Use the Back to Top Button section
        'settings' => 'kartnic_back_to_top',
        'type' => 'checkbox',
    ));

    // Add settings for header background color with sanitization callback
    $wp_customize->add_setting('header_bg_color', array(
        'default'   => '#ffffff',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_hex_color',
    ));

    // Add settings for header text color with sanitization callback
    $wp_customize->add_setting('header_text_color', array(
        'default'   => '#333333',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_hex_color',
    ));

    // Add control for focus color
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'focus_color_control', array(
        'label'    => __('Focus Color', 'kartnic'),
        'section'  => 'colors',
        'settings' => 'focus_color',
    )));

    // Add control for header background color
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'header_bg_color_control', array(
        'label'    => __('Header Background Color', 'kartnic'),
        'section'  => 'colors',
        'settings' => 'header_bg_color',
    )));

    // Add control for header text color
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'header_text_color_control', array(
        'label'    => __('Header Text Color', 'kartnic'),
        'section'  => 'colors',
        'settings' => 'header_text_color',
    )));

    // Add setting for logo width with sanitization callback
    $wp_customize->add_setting('kartnic_logo_width', array(
        'default' => '150',
        'transport' => 'postMessage', // Use postMessage for live preview
        'sanitize_callback' => 'absint', // Add sanitization callback here
    ));

    // Add slider control for logo width
    $wp_customize->add_control('kartnic_logo_width_control', array(
        'label' => __('Logo Width (px)', 'kartnic'),
        'section' => 'title_tagline',
        'settings' => 'kartnic_logo_width',
        'type' => 'range',
        'input_attrs' => array(
            'min' => 50, // Minimum value
            'max' => 300, // Maximum value
            'step' => 1, // Step size
        ),
    ));

    // Add setting for logo upload
    $wp_customize->add_setting('kartnic_logo', array(
        'default' => '',
        'transport' => 'postMessage',
        'sanitize_callback' => 'esc_url_raw',
    ));

    // Add control for logo upload
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'kartnic_logo_control', array(
        'label' => __('Upload Logo', 'kartnic'),
        'section' => 'title_tagline',
        'settings' => 'kartnic_logo',
    )));

    // Add control for Layout
    $wp_customize->add_control('kartnic_layout_control', array(
        'label' => __('Select Layout', 'kartnic'),
        'section' => 'layout_section',
        'settings' => 'kartnic_layout_setting',
        'type' => 'radio',
        'choices' => array(
            'left-sidebar' => __('Left Sidebar', 'kartnic'),
            'right-sidebar' => __('Right Sidebar', 'kartnic'),
            'no-sidebar' => __('No Sidebar', 'kartnic'),
        ),
    ));

    // Add section for Blog inside Layout
    $wp_customize->add_section('kartnic_blog_section', array(
        'title' => __('Blog', 'kartnic'),
        'priority' => 36,
    ));

    // Add setting for blog excerpt length
    $wp_customize->add_setting('kartnic_blog_excerpt_length', array(
        'default' => 55, // Default length
        'sanitize_callback' => 'absint',
    ));

    // Add control for blog excerpt length
    $wp_customize->add_control('kartnic_blog_excerpt_length_control', array(
        'label' => __('Excerpt Length (words)', 'kartnic'),
        'section' => 'kartnic_blog_section',
        'settings' => 'kartnic_blog_excerpt_length',
        'type' => 'number',
        'input_attrs' => array(
            'min' => 10, // Minimum value
            'max' => 200, // Maximum value
            'step' => 1, // Step size
        ),
    ));

    if ( ! function_exists( 'is_plugin_active' ) ) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }
    
    if ( ! is_plugin_active( 'kartnic-premium/kartnic-premium.php' ) ) {
        // Add notice and button below the excerpt length control
        $wp_customize->add_setting('kartnic_premium_notice', array(
            'sanitize_callback' => 'wp_kses_post',
        ));
    
        $premium_url = '#'; // Define the variable
    
        $wp_customize->add_control(new WP_Customize_Control(
            $wp_customize,
            'kartnic_premium_notice',
            array(
                'description' => '<p>More options are available for this section in our premium version.</p><a href="' . $premium_url . '" class="button button-primary">Learn more</a>',
                'section' => 'kartnic_blog_section', // Replace with your section ID
                'settings' => 'kartnic_premium_notice',
                'type' => 'hidden', // Hidden type to display only description
            )
        ));
    }

    // Add section for Sidebar inside Layout
    $wp_customize->add_section('kartnic_sidebar_section', array(
        'title' => __('Sidebar', 'kartnic'),
        'priority' => 37,
    ));

        // Add setting for sidebar position
        $wp_customize->add_setting('kartnic_sidebar_position', array(
            'default' => 'right',
            'sanitize_callback' => 'sanitize_text_field',
        ));
    
        // Add control for sidebar position
        $wp_customize->add_control('kartnic_sidebar_position_control', array(
            'label' => __('Sidebar Position', 'kartnic'),
            'section' => 'kartnic_sidebar_section',
            'settings' => 'kartnic_sidebar_position',
            'type' => 'radio',
            'choices' => array(
                'left' => __('Left', 'kartnic'),
                'right' => __('Right', 'kartnic'),
                'no-sidebar' => __('No Sidebar', 'kartnic'),
            ),
        ));
    }
    add_action('customize_register', 'kartnic_customizer_settings');
    
    function kartnic_custom_excerpt($length = 55) {
        $excerpt_length = get_theme_mod('kartnic_blog_excerpt_length', $length);
        error_log('Excerpt Length: ' . $excerpt_length);
        
        $excerpt = get_the_excerpt();
        if (empty($excerpt)) {
            $excerpt = get_the_content();
        }
        $excerpt = wp_trim_words($excerpt, $excerpt_length, '...');
        error_log('Excerpt: ' . $excerpt);
        return $excerpt;
    }    
    
    function kartnic_sidebar_position_class($classes) {
        $sidebar_position = get_theme_mod('kartnic_sidebar_position', 'right');
        $classes[] = 'sidebar-' . esc_attr($sidebar_position);
        return $classes;
    }
    add_filter('body_class', 'kartnic_sidebar_position_class');
    
    function kartnic_customize_register($wp_customize) {
        // Add a section for the footer settings
        $wp_customize->add_section('kartnic_footer_section', array(
            'title' => __('Footer Settings', 'kartnic'),
            'priority' => 30,
        ));
    
        // Add a setting for the copyright text
        $wp_customize->add_setting('kartnic_copyright_text', array(
            'default' => '© ' . date('Y') . ' ' . get_bloginfo('name'),
            'sanitize_callback' => 'sanitize_text_field',
        ));
    
        // Add a setting for the site link
        $wp_customize->add_setting('kartnic_site_link', array(
            'default' => home_url(), // Default to the site URL
            'sanitize_callback' => 'esc_url_raw',
        ));

    
        // Add a control to change the copyright text
        $wp_customize->add_control('kartnic_copyright_text_control', array(
            'label' => __('Copyright Text', 'kartnic'),
            'section' => 'kartnic_footer_section',
            'settings' => 'kartnic_copyright_text',
            'type' => 'text',
        ));
    
        // Add a control to change the site link
        $wp_customize->add_control('kartnic_site_link_control', array(
            'label' => __('Site Link', 'kartnic'),
            'section' => 'kartnic_footer_section',
            'settings' => 'kartnic_site_link',
            'type' => 'url',
        ));
    
        // Remove the header text color control
        $wp_customize->remove_control('header_textcolor');
    }
    add_action('customize_register', 'kartnic_customize_register');
    
    // Function to display the dynamic copyright text with site link and credit
    function kartnic_dynamic_copyright() {
        $site_link = get_theme_mod('kartnic_site_link', home_url()); // Changed get_site_url() to home_url()
        $site_name = get_bloginfo('name');
        $current_year = date('Y');
        $copyright_text = get_theme_mod('kartnic_copyright_text', '© ' . $current_year . ' ' . $site_name);

        if ($site_link === '#' || empty($site_link)) {
            return esc_html($copyright_text) . ' • Built with <a href="https://kartnic.com">Kartnic</a>';
        } else {
            return str_replace($site_name, '<a href="' . esc_url($site_link) . '">' . esc_html($site_name) . '</a>', esc_html($copyright_text)) . ' • Built with <a href="https://kartnic.com">Kartnic</a>';
        }
    }

    
    // Hook to display the dynamic copyright text in the footer
    add_action('wp_footer', 'kartnic_dynamic_copyright');
    
    function kartnic_enqueue_scripts() {
        // Enqueue back-to-top script
        wp_enqueue_script('back-to-top', get_template_directory_uri() . '/js/back-to-top.js', array('jquery'), null, true);
        wp_localize_script('back-to-top', 'kartnic_back_to_top_enabled', array(
            'enabled' => get_theme_mod('kartnic_back_to_top', false)
        ));
    
        // Enqueue menu script
        wp_enqueue_script('menu-script', get_template_directory_uri() . '/js/menu.js', array('jquery'), null, true);
        wp_localize_script('menu-script', 'kartnic_menu_enabled', array(
            'enabled' => get_theme_mod('kartnic_menu', false)
        ));
    
        // Enqueue search script
        wp_enqueue_script('search-script', get_template_directory_uri() . '/js/search.js', array('jquery'), null, true);
    }
    add_action('wp_enqueue_scripts', 'kartnic_enqueue_scripts');
    
    // Register custom block patterns
    function kartnic_register_block_patterns() {
        register_block_pattern(
            'kartnic/kartnic-awesome-pattern',
            array(
                'title'       => __( 'My Awesome Pattern', 'kartnic' ),
                'description' => _x( 'A description of kartnic awesome pattern', 'Block pattern description', 'kartnic' ),
                'content'     => "<!-- wp:paragraph --><p>" . __( 'Hello World', 'kartnic' ) . "</p><!-- /wp:paragraph -->",
            )
        );
    }
    add_action( 'init', 'kartnic_register_block_patterns' );
    
    // Register custom block styles
    function kartnic_register_block_styles() {
        register_block_style(
            'core/paragraph',
            array(
                'name'  => 'fancy-paragraph',
                'label' => __( 'Fancy Paragraph', 'kartnic' ),
            )
        );
    }
    add_action( 'init', 'kartnic_register_block_styles' );
    
    // Enqueue comment-reply script
    function kartnic_enqueue_comment_reply_script() {
        if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
            wp_enqueue_script( 'comment-reply' );
        }
    }
    add_action( 'wp_enqueue_scripts', 'kartnic_enqueue_comment_reply_script' );
    
    // Enqueue customize preview script
    function kartnic_customize_preview_js() {
        wp_enqueue_script('kartnic-customize-preview', get_template_directory_uri() . '/js/customize-preview.js', array('customize-preview'), '1.0', true);
    }
    add_action('customize_preview_init', 'kartnic_customize_preview_js');
    
    // Register sidebars in a custom function hooked to widgets_init
    function kartnic_widgets_init() {
        register_sidebar(array(
            'name' => esc_html__('Sidebar Location', 'kartnic'),
            'id' => 'sidebar',
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget' => '</section>',
            'before_title' => '<h3>',
            'after_title' => '</h3>',
        ));
        register_sidebar(array(
            'name' => esc_html__('Footer 1', 'kartnic'),
            'id' => 'footer1',
            'description' => esc_html__('Add Widgets Here for the content of footer1', 'kartnic'),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget' => '</section>',
            'before_title' => '<h3>',
            'after_title' => '</h3>',
        ));
        register_sidebar(array(
            'name' => esc_html__('Footer 2', 'kartnic'),
            'id' => 'footer2',
            'description' => esc_html__('Add Widgets Here for the content of footer2', 'kartnic'),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget' => '</section>',
            'before_title' => '<h3>',
            'after_title' => '</h3>',
        ));
        register_sidebar(array(
            'name' => esc_html__('Footer 3', 'kartnic'),
            'id' => 'footer3',
            'description' => esc_html__('Add Widgets Here for the content of footer3', 'kartnic'),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget' => '</section>',
            'before_title' => '<h3>',
            'after_title' => '</h3>',
        ));
        register_sidebar(array(
            'name' => esc_html__('Footer 4', 'kartnic'),
            'id' => 'footer4',
            'description' => esc_html__('Add Widgets Here for the content of footer4', 'kartnic'),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget' => '</section>',
            'before_title' => '<h3>',
            'after_title' => '</h3>',
        ));
    }
    add_action('widgets_init', 'kartnic_widgets_init');

    function kartnic_custom_typography_settings($wp_customize) {
        // Add settings for site-cont background and text color
        $wp_customize->add_setting('site_cont_bg_color', array(
            'default'   => '#ffffff',
            'transport' => 'refresh',
            'sanitize_callback' => 'sanitize_hex_color', 
        ));
        $wp_customize->add_setting('site_cont_text_color', array(
            'default'   => '#000000',
            'transport' => 'refresh',
            'sanitize_callback' => 'sanitize_hex_color', 
        ));
    
        // Add settings for pagination background and text color
        $wp_customize->add_setting('pagination_bg_color', array(
            'default'   => '#f0f0f0',
            'transport' => 'refresh',
            'sanitize_callback' => 'sanitize_hex_color',
        ));
        $wp_customize->add_setting('pagination_text_color', array(
            'default'   => '#333333',
            'transport' => 'refresh',
            'sanitize_callback' => 'sanitize_hex_color', 
        ));
    
        // Add controls for site-cont colors
        $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'site_cont_bg_color', array(
            'label'    => __('Site Container Background Color', 'kartnic'),
            'section'  => 'colors',
            'settings' => 'site_cont_bg_color',
        )));
        $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'site_cont_text_color', array(
            'label'    => __('Site Container Text Color', 'kartnic'),
            'section'  => 'colors',
            'settings' => 'site_cont_text_color',
        )));
    
        // Add controls for pagination colors
        $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'pagination_bg_color', array(
            'label'    => __('Pagination Background Color', 'kartnic'),
            'section'  => 'colors',
            'settings' => 'pagination_bg_color',
        )));
        $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'pagination_text_color', array(
            'label'    => __('Pagination Text Color', 'kartnic'),
            'section'  => 'colors',
            'settings' => 'pagination_text_color',
        )));
    
    
            // Add settings for post-navigation background and text color
            $wp_customize->add_setting('post_navigation_bg_color', array(
                'default'   => '#f0f0f0',
                'transport' => 'refresh',
                'sanitize_callback' => 'sanitize_hex_color', 
            ));
            $wp_customize->add_setting('post_navigation_text_color', array(
                'default'   => '#333333',
                'transport' => 'refresh',
                'sanitize_callback' => 'sanitize_hex_color', 
            ));
        
            // Add settings for post-site-main background and text color
            $wp_customize->add_setting('post_site_main_bg_color', array(
                'default'   => '#ffffff',
                'transport' => 'refresh',
                'sanitize_callback' => 'sanitize_hex_color', 
            ));
            $wp_customize->add_setting('post_site_main_text_color', array(
                'default'   => '#000000',
                'transport' => 'refresh',
                'sanitize_callback' => 'sanitize_hex_color', 
            ));
        
            // Add controls for post-navigation colors
            $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'post_navigation_bg_color', array(
                'label'    => __('Post Navigation Background Color', 'kartnic'),
                'section'  => 'colors',
                'settings' => 'post_navigation_bg_color',
            )));
            $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'post_navigation_text_color', array(
                'label'    => __('Post Navigation Text Color', 'kartnic'),
                'section'  => 'colors',
                'settings' => 'post_navigation_text_color',
            )));
        
            // Add controls for post-site-main colors
            $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'post_site_main_bg_color', array(
                'label'    => __('Post Site Main Background Color', 'kartnic'),
                'section'  => 'colors',
                'settings' => 'post_site_main_bg_color',
            )));
            $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'post_site_main_text_color', array(
                'label'    => __('Post Site Main Text Color', 'kartnic'),
                'section'  => 'colors',
                'settings' => 'post_site_main_text_color',
            )));
    
        // Sidebar Background Color
            $wp_customize->add_setting('sidebar_bg_color', array(
                'default' => '#ffffff',
                'transport' => 'refresh',
                'sanitize_callback' => 'sanitize_hex_color', 
            ));
        
            $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'sidebar_bg_color_control', array(
                'label' => __('Sidebar Background Color', 'kartnic'),
                'section' => 'colors',
                'settings' => 'sidebar_bg_color',
            )));
        
            // Sidebar Text Color
            $wp_customize->add_setting('sidebar_text_color', array(
                'default' => '#333333',
                'transport' => 'refresh',
                'sanitize_callback' => 'sanitize_hex_color', 
            ));
        
            $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'sidebar_text_color_control', array(
                'label' => __('Sidebar Text Color', 'kartnic'),
                'section' => 'colors',
                'settings' => 'sidebar_text_color',
        )));

        // Button Background Color
        $wp_customize->add_setting('button_bg_color', array(
            'default' => '#333333',
            'transport' => 'refresh',
            'sanitize_callback' => 'sanitize_hex_color',
        ));
    
        $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'button_bg_color_control', array(
            'label' => __('Button Background Color', 'kartnic'),
            'section' => 'colors',
            'settings' => 'button_bg_color',
        )));
    
        // Button Text Color
        $wp_customize->add_setting('button_text_color', array(
            'default' => '#ffffff',
            'transport' => 'refresh',
            'sanitize_callback' => 'sanitize_hex_color', 
        ));
    
        $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'button_text_color_control', array(
            'label' => __('Button Text Color', 'kartnic'),
            'section' => 'colors',
            'settings' => 'button_text_color',
        )));
    
        $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'button_text_color_control', array(
            'label' => __('Button Text Color', 'kartnic'),
            'section' => 'colors',
            'settings' => 'button_text_color',
        )));
        // Site Info Background Color
        $wp_customize->add_setting('footer_bg_color', array(
            'default' => '#ffffff',
            'transport' => 'refresh',
            'sanitize_callback' => 'sanitize_hex_color', 
        ));
    
        $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'footer_bg_color_control', array(
            'label' => __('Footer Background Color', 'kartnic'),
            'section' => 'colors',
            'settings' => 'footer_bg_color',
        )));
    
        // Site Info Text Color
        $wp_customize->add_setting('footer_text_color', array(
            'default' => '#333333',
            'transport' => 'refresh',
            'sanitize_callback' => 'sanitize_hex_color', 
        ));
    
        $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'footer_text_color_control', array(
            'label' => __('Footer Text Color', 'kartnic'),
            'section' => 'colors',
            'settings' => 'site_info_text_color',
        )));
    
            // Navigation Background Color
            $wp_customize->add_setting('nav_bg_color', array(
                'default' => '#ffffff',
                'transport' => 'refresh',
                'sanitize_callback' => 'sanitize_hex_color', 
            ));
        
            $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'nav_bg_color_control', array(
                'label' => __('Navigation Background Color', 'kartnic'),
                'section' => 'colors',
                'settings' => 'nav_bg_color',
            )));
        
            // Navigation Text Color
            $wp_customize->add_setting('nav_text_color', array(
                'default' => '#333333',
                'transport' => 'refresh',
                'sanitize_callback' => 'sanitize_hex_color', 
            ));
        
            $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'nav_text_color_control', array(
                'label' => __('Navigation Text Color', 'kartnic'),
                'section' => 'colors',
                'settings' => 'nav_text_color',
            )));
        
        // Add a section for typography
        $wp_customize->add_section('typography_section', array(
            'title' => __('Typography', 'kartnic'),
            'priority' => 30,
        ));
    
    // Add settings and controls for H1 to H6 font sizes, weights, letter spacing, line height, and font family
$headings = array('H1', 'H2', 'H3', 'H4', 'H5', 'H6');
foreach ($headings as $heading) {
    // Font size setting and control
    $wp_customize->add_setting("{$heading}_font_size", array(
        'default' => '16px',
        'sanitize_callback' => 'sanitize_text_field',
    ));

    $wp_customize->add_control("{$heading}_font_size_control", array(
        'label' => sprintf( __( '%s Font Size', 'kartnic' ), $heading ),
        'section' => 'typography_section',
        'settings' => "{$heading}_font_size",
        'type' => 'text',
    ));

    // Font weight setting and control
    $wp_customize->add_setting("{$heading}_font_weight", array(
        'default' => '400',
        'sanitize_callback' => 'sanitize_text_field',
    ));

    $wp_customize->add_control("{$heading}_font_weight_control", array(
        'label' => sprintf( __( '%s Font Weight', 'kartnic' ), $heading ),
        'section' => 'typography_section',
        'settings' => "{$heading}_font_weight",
        'type' => 'select',
        'choices' => array(
            '100' => '100',
            '200' => '200',
            '300' => '300',
            '400' => '400',
            '500' => '500',
            '600' => '600',
            '700' => '700',
            '800' => '800',
            '900' => '900',
        ),
    ));

    // Letter spacing setting and control
    $wp_customize->add_setting("{$heading}_letter_spacing", array(
        'default' => '0px',
        'sanitize_callback' => 'sanitize_text_field',
    ));

    $wp_customize->add_control("{$heading}_letter_spacing_control", array(
        'label' => sprintf( __( '%s Letter Spacing', 'kartnic' ), $heading ),
        'section' => 'typography_section',
        'settings' => "{$heading}_letter_spacing",
        'type' => 'text',
    ));

    // Line height setting and control
    $wp_customize->add_setting("{$heading}_line_height", array(
        'default' => '1.5',
        'sanitize_callback' => 'sanitize_text_field',
    ));

    $wp_customize->add_control("{$heading}_line_height_control", array(
        'label' => sprintf( __( '%s Line Height', 'kartnic' ), $heading ),
        'section' => 'typography_section',
        'settings' => "{$heading}_line_height",
        'type' => 'text',
    ));

    // Font family setting and control
    $wp_customize->add_setting("{$heading}_font_family", array(
        'default' => 'Arial, sans-serif',
        'sanitize_callback' => 'sanitize_text_field',
    ));

    $wp_customize->add_control("{$heading}_font_family_control", array(
        'label' => sprintf( __( '%s Font Family', 'kartnic' ), $heading ),
        'section' => 'typography_section',
        'settings' => "{$heading}_font_family",
        'type' => 'text',
    ));
}
    
    // Add settings and controls for paragraph font size, weight, letter spacing, line height, bottom margin, and font family
    $wp_customize->add_setting('paragraph_font_size', array(
        'default' => '16px',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('paragraph_font_size_control', array(
        'label' => __('Paragraph Font Size', 'kartnic'),
        'section' => 'typography_section',
        'settings' => 'paragraph_font_size',
        'type' => 'text',
    ));
    
    $wp_customize->add_setting('paragraph_font_weight', array(
        'default' => '400',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('paragraph_font_weight_control', array(
        'label' => __('Paragraph Font Weight', 'kartnic'),
        'section' => 'typography_section',
        'settings' => 'paragraph_font_weight',
        'type' => 'select',
        'choices' => array(
            '100' => '100',
            '200' => '200',
            '300' => '300',
            '400' => '400',
            '500' => '500',
            '600' => '600',
            '700' => '700',
            '800' => '800',
            '900' => '900',
        ),
    ));
    
    $wp_customize->add_setting('paragraph_letter_spacing', array(
        'default' => '0px',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('paragraph_letter_spacing_control', array(
        'label' => __('Paragraph Letter Spacing', 'kartnic'),
        'section' => 'typography_section',
        'settings' => 'paragraph_letter_spacing',
        'type' => 'text',
    ));
    
    $wp_customize->add_setting('paragraph_line_height', array(
        'default' => '1.5',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('paragraph_line_height_control', array(
        'label' => __('Paragraph Line Height', 'kartnic'),
        'section' => 'typography_section',
        'settings' => 'paragraph_line_height',
        'type' => 'text',
    ));
    
    $wp_customize->add_setting('paragraph_bottom_margin', array(
        'default' => '0px',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('paragraph_bottom_margin_control', array(
        'label' => __('Paragraph Bottom Margin', 'kartnic'),
        'section' => 'typography_section',
        'settings' => 'paragraph_bottom_margin',
        'type' => 'text',
    ));
    
    $wp_customize->add_setting('paragraph_font_family', array(
        'default' => 'Arial, sans-serif',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('paragraph_font_family_control', array(
        'label' => __('Paragraph Font Family', 'kartnic'),
        'section' => 'typography_section',
        'settings' => 'paragraph_font_family',
        'type' => 'text',
    ));
    
      
    }
    
    add_action('customize_register', 'kartnic_custom_typography_settings');
    
     
    
 
