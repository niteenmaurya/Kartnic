<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package Kartnic
 */
get_header();
$cat = get_categories(array('taxonomy' => 'category'));
?>

<div class="site-content-area" id="content">
    <h1 class="page-title">Search Results for: <?php echo get_search_query(); ?></h1>
    <div class="site-cont" id="cont-site">
        <?php while (have_posts()) {
            the_post();
            $imagepath = wp_get_attachment_image_src(get_post_thumbnail_id(), 'large');
        ?>
            <article>
                <div class="inside-article">
                    <div class="post-image">
                        <a href="<?php the_permalink(); ?>">
                            <img src="<?php echo $imagepath[0]; ?>" style="width: 100%; height: auto;" alt="<?php the_title(); ?>" />
                        </a>
                    </div>
                    <header class="entry-header">
                        <h2 class="main-entry-title" itemprop="headline">
                            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                        </h2>
                        <div class="entry-meta">
                            <span class="byline">
                                by&nbsp;<a href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>"><?php the_author(); ?></a>
                            </span>
                            <span class="posted-on"><?php echo get_the_date(); ?></span>
                        </div>
                    </header>
                </div>
                <div class="entry-summary" itemprop="text"><?php the_excerpt(); ?></div>
                <a href="<?php the_permalink(); ?>"><input type="button" value="Read more" name=" "></a>
            </article>
        <?php } ?>
    </div>
</div>
<?php
get_footer();
?>
